/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123220115tugas1;

/**
 *
 * @author L E N O V O
 */
public class polymorphism {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        atlet a[] = new atlet[3];
        a[0] = new atlet();
        a[1] = new petinju();
        a[2] = new atletSepakbola();
                
        for (int i = 0; i < 3; i++) {
            System.out.println("Gaji Atlet " + i + " perbulan Rp."+a[i].getGajiBulanan()+" Selama "+a[i].Kontrak+" Tahun Kontrak");
        }
        System.out.println("");
        
        for (int i = 0; i < 3; i++) {
            System.out.println("Total gaji Atlet " + i + " adalah Rp." + a[i].getGajiTotal());
        }
        System.out.println("");
        
        for (int i = 0; i < 3; i++) {
            System.out.print("Atlet " + i + " "); 
            a[i].DapatBonus();
        }
        System.out.println("");
        
        for (int i = 0; i < 3; i++) {
            System.out.println("Total gaji Atlet " + i + " sekarang yaitu Rp." + a[i].getGajiTotal());
        }
    }
}
