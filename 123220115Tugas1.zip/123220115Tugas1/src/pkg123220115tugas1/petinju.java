/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123220115tugas1;

/**
 *
 * @author L E N O V O
 */
public class petinju extends atlet{
    petinju(){
        setGaji(8500000);
        Kontrak = 3;
        Bonus = 0;
    }
    
    void DapatBonus(){
        Bonus += 1000000;
        System.out.println("Dapat bonus Rp.1.000.000");
    }
}
