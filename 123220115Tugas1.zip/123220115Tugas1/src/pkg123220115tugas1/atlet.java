/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123220115tugas1;

/**
 *
 * @author L E N O V O
 */
public class atlet {
    private int GajiBulanan;
    int Kontrak;
    int Bonus;
    
    atlet(){
        GajiBulanan = 6000000;
        Kontrak = 2;
        Bonus = 0;
    }
    
    void setGaji(int gaji){
        this.GajiBulanan = gaji;
    }
    
    private int HitungGaji(int GajiBulanan, int Kontrak){
        return (GajiBulanan*Kontrak*12)+Bonus;
    }
    
    int getGajiBulanan(){
        return GajiBulanan;
    }
    
    int getGajiTotal(){
        return HitungGaji(GajiBulanan, Kontrak);
    } 
    
    void DapatBonus(){
        System.out.println("Tidak dapat bonus");
    }
    
    
}
